<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once("BandoDeDados/conectaBd.php");

if (!isset($_SESSION["usuario_logado"]) || $_SESSION["usuario_logado"] !== true) {
    header("Location: index.php");
    exit;
}

$usuario_id = $_SESSION['id'];

// Obtém a senha antiga do formulário
$senhaAntiga = isset($_POST['senhaAntiga']) ? $_POST['senhaAntiga'] : null;

// Verifica se a senha antiga está correta
$queryVerificaSenha = "SELECT senha FROM usuarios WHERE id = ?";
$stmtVerificaSenha = $conn->prepare($queryVerificaSenha);
$stmtVerificaSenha->bind_param("i", $usuario_id);
$stmtVerificaSenha->execute();
$stmtVerificaSenha->store_result();

if ($stmtVerificaSenha->num_rows > 0) {
    $stmtVerificaSenha->bind_result($senhaArmazenada);
    $stmtVerificaSenha->fetch();

    if (password_verify($senhaAntiga, $senhaArmazenada)) {
        // Senha antiga está correta, continue com a atualização
        $novoNome = isset($_POST['nome']) ? $_POST['nome'] : null;
        $novaSenha = isset($_POST['novaSenha']) ? $_POST['novaSenha'] : null;
        $novoEmail = isset($_POST['novoEmail']) ? $_POST['novoEmail'] : null;
        $novoCEP = isset($_POST['novoCEP']) ? $_POST['novoCEP'] : null;
        $novaRua = isset($_POST['novaRua']) ? $_POST['novaRua'] : null;
        $novoMunicipio = isset($_POST['novoMunicipio']) ? $_POST['novoMunicipio'] : null;
        $novoEstado = isset($_POST['novoEstado']) ? $_POST['novoEstado'] : null;
        $novoTelefone = isset($_POST['novoTelefone']) ? $_POST['novoTelefone'] : null;

        // Verificar se um arquivo foi enviado
        if (isset($_FILES['foto'])) {
            $foto = $_FILES['foto'];
            
            // Verifica se não houve erro no upload
            if ($foto['error'] === 0) {
                $foto_nome = $foto['name'];
                $foto_temp = $foto['tmp_name'];
        
                // Salva a foto no banco de dados ou em um diretório, dependendo dos requisitos
                // Exemplo de salvamento em diretório:
                $destino = 'caminho/do/seu/diretorio/' . $foto_nome;
                move_uploaded_file($foto_temp, $destino);
        
                // Atualiza a coluna 'foto' no banco de dados
                $query_update_foto = "UPDATE usuarios SET foto = ? WHERE id = ?";
                $stmt_update_foto = $conn->prepare($query_update_foto);
                $stmt_update_foto->bind_param("si", $destino, $usuario_id);
                $stmt_update_foto->execute();
                $stmt_update_foto->close();
            }
        }
        // Preparar um array para armazenar os campos e valores a serem atualizados
        $camposAtualizados = [];
        $tiposDados = '';
        $valores = [];

        // Verificar e adicionar os campos que foram preenchidos
        if (!empty($novoNome)) {
            $camposAtualizados[] = "nome = ?";
            $tiposDados .= 's';
            $valores[] = $novoNome;
        }
        if (!empty($novaSenha)) {
            $camposAtualizados[] = "senha = ?";
            $tiposDados .= 's';
            $valores[] = $novaSenha;
        }
        if (!empty($novoEmail)) {
            $camposAtualizados[] = "email = ?";
            $tiposDados .= 's';
            $valores[] = $novoEmail;
        }
        if (!empty($novoCEP)) {
            $camposAtualizados[] = "cep = ?";
            $tiposDados .= 's';
            $valores[] = $novoCEP;
        }
        if (!empty($novaRua)) {
            $camposAtualizados[] = "rua = ?";
            $tiposDados .= 's';
            $valores[] = $novaRua;
        }
        if (!empty($novoMunicipio)) {
            $camposAtualizados[] = "municipio = ?";
            $tiposDados .= 's';
            $valores[] = $novoMunicipio;
        }
        if (!empty($novoEstado)) {
            $camposAtualizados[] = "estado = ?";
            $tiposDados .= 's';
            $valores[] = $novoEstado;
        }
        if (!empty($novoTelefone)) {
            $camposAtualizados[] = "telefone = ?";
            $tiposDados .= 's';
            $valores[] = $novoTelefone;
        }

        if (!empty($camposAtualizados)) {
            // Prepara a instrução SQL para atualização
            $query = "UPDATE usuarios SET " . implode(', ', $camposAtualizados) . " WHERE id = ?";
            $stmt = $conn->prepare($query);

            // Adapta o bind_param para aceitar diferentes tipos de dados
            $parametros = array_merge([$tiposDados . 'i'], $valores, [$usuario_id]);
            call_user_func_array([$stmt, 'bind_param'], $parametros);

            if ($stmt->execute()) {
                // Atualização bem-sucedida
                header("Location: home.php");
                exit;
            } else {
                // Erro na atualização
                echo "Erro na atualização: " . $stmt->error;
            }

            $stmt->close();
        } else {
            // Nenhum campo fornecido para atualização
            echo "Nenhum campo fornecido para atualização.";
        }
    } else {
        // Senha antiga incorreta
        echo "Senha antiga incorreta.";
    }
} else {
    // Erro ao verificar a senha antiga
    echo "Erro ao verificar a senha antiga.";
}

$stmtVerificaSenha->close();
?>
