<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'u602544677_NetoNerd';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli($host, $user, $password, $database);

    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }

    $email = $_POST["email"];

    $query = "SELECT * FROM usuarios WHERE email = '$email'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $token = bin2hex(random_bytes(32));
        $expira = date('Y-m-d H:i:s', strtotime('+15 minutes'));

        $updateQuery = "UPDATE usuarios SET token = '$token', expira_em = '$expira' WHERE email = '$email'";
        $conn->query($updateQuery);

        // Configuração do PHPMailer
        $mail = new PHPMailer(true);

        try {
            $mail->SMTPDebug = 2; // Nível de depuração
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'rondi.rio@gmail.com';
            $mail->Password = 'fyin dkuc xgem tvid';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('rondi.rio@gmail.com', 'Rondineli Oliveira');
            $mail->addAddress($email);

            $mail->Subject = 'Recuperação de Senha';
            $mail->Body = "Clique no link a seguir para redefinir sua senha: http://seusite.com/reset.php?token=$token";

            $mail->send();

            echo "Um e-mail com as instruções de recuperação foi enviado para o seu endereço de e-mail.";
        } catch (Exception $e) {
            echo "Erro no envio do e-mail: {$mail->ErrorInfo}";
        }
    } else {
        echo "E-mail não cadastrado.";
    }

    $conn->close();
}
?>
