p

<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once("BandoDeDados/conectaBd.php");

if (!isset($_SESSION["usuario_logado"]) || $_SESSION["usuario_logado"] !== true) {
    header("Location: index.php");
    exit;
}

$usuario_id = $_SESSION['id'];

// Obtém o ID do usuário logado
$usuario_id = $_SESSION['id'];

// Consulta SQL para obter os dados do usuário
$query = "SELECT nome, email, idade, cep, rua, municipio, estado, telefone, foto FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$stmt->bind_result($nome, $email, $idade, $cep, $rua, $municipio, $estado, $telefone, $foto);
$stmt->fetch();
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Neto Nerd</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Free HTML5 Website Template " />
    <meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />

    <!-- Bootstrap  -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- Owl Carousel  -->
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <!-- Animate.css -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">

    <!-- Theme style  -->
    <link rel="stylesheet" href="css/style.css">
    <link src="javascript/MudaDado.js">
    <!-- jQuery e Cropper.js -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="cropperjs-main/dist/cropper.js"></script>

<!-- Substitua os scripts JavaScript existentes pelos seguintes: -->

<script>
    function exibirFotoSelecionada() {
        const inputFoto = document.getElementById('fotoInput');
        const imagemFoto = document.getElementById('imagemFoto');

        if (inputFoto.files && inputFoto.files[0]) {
            const reader = new FileReader();

            reader.onload = function (e) {
                imagemFoto.src = e.target.result;
            };

            reader.readAsDataURL(inputFoto.files[0]);
        }
    }
    function salvarAjustes() {
    const inputFoto = document.getElementById('fotoInput');
    const fotoSelecionada = inputFoto.files[0];

    const formData = new FormData();
    formData.append('foto', fotoSelecionada);

    // Use AJAX para enviar a foto para o PHP
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'atualiza_dados.php', true); // Atualize o caminho do script PHP

    xhr.onload = function () {
        // Lógica para tratar a resposta do servidor, se necessário
        console.log('Imagem atualizada com sucesso!');
    };
    xhr.send(formData);
}

</script>
    <style>
        body {
        
            background-color: #f0f8ff; /* Cor de fundo em tons de azul claro */
            font-family: Arial, sans-serif; /* Fonte fácil de ler para idosos */
            color: #333; /* Cor do texto principal */
        }
        .container.dados-usuario {
            display: block;
            background-color: #d3e0ea; /* Cor de fundo mais escura para a área de dados do usuário */
            padding: 20px;
            margin: 100px;
            border-radius: 10px; /* Borda arredondada para suavizar a aparência */
        }
        h2 {
            color: #004080; /* Cor mais escura para o título */
        }
        label {
            color: #004080; /* Cor mais escura para as etiquetas */
        }
        .form-control {
            background-color: #edf4f8; /* Cor de fundo mais clara para os campos de formulário */
        }
        .btn-primary {
            background-color: #004080; /* Cor de fundo mais escura para o botão */
            color: #fff; /* Cor do texto no botão */
            border: none; /* Remover a borda para um visual mais limpo */
        }
    </style>
</head>
<body>
    <div id="page-wrap">
        <div id="fh5co-hero-wrapper">
        <nav class="container navbar navbar-expand-lg main-navbar-nav navbar-light">
        <a class="navbar-brand" href="">Neto Nerd</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-items-center ml-auto mr-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Inicio <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="dicas.php" onclick="$('#fh5co-features').goTo();return false;">Dicas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="chamados_populares.php" onclick="$('#fh5co-reviews').goTo();return false;">Chamados populares</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login.php"  onclick="$('#fh5co-download').goTo();return false;">Login</a>
                </li>
                <!-- Botão para abrir o painel lateral -->
                <li class="nav-item">
                    <button class="btn btn-link btn-engrenagem">
                        <i class="fas fa-cog btn-lg bg-dark"></i> <!-- Ícone de engrenagem -->
                    </button>
                </li>
            </ul>
            <a href="logout.php" class="btn btn-danger">Sair</a>
            <div class="social-icons-header">
                <a href="https://www.facebook.com/profile.php?id=100093194543537"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.instagram.com/fourba.oficial/?next=%2F"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </nav>
    <!-- Trecho de código na seção de atualização de dados da conta -->
<div class="container dados-usuario " style="display: none;">
    <div class="row">
        <div class="col-md-6">
            <h2>Meus Dados</h2>
            <div class="dados-usuario" >
            <?php
            // Buscar dados atuais do usuário no banco de dados
            $query = "SELECT nome, email, cep, rua, municipio, estado, telefone FROM usuarios WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $usuario_id);
            $stmt->execute();
            $stmt->bind_result($nome, $email, $cep, $rua, $municipio, $estado, $telefone);
            $stmt->fetch();
            $stmt->close();
            ?>
<div class="form-group">
<label for="foto">Nova Foto:</label>
<div class="input-group">
    <span class="input-group-btn">
        <input type="file" class="form-control" id="fotoInput">
        <button class="btn btn-primary" type="button" onclick="salvarAjustes()">
            <img id="imagemFoto" src="<?php echo $foto; ?>" alt="Foto do Usuário" style="max-width: 100%; height: auto;">
        </button>
    </span>
</div>
<img id="fotoPadrao" src="img/user2.png" alt="Foto Padrão" style="max-width: 100%; height: auto;">
</div>

<!-- Modal para ajustar a foto -->
<div class="modal fade" id="modalFoto" tabindex="-1" role="dialog" aria-labelledby="modalFotoLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalFotoLabel">Ajustar Foto</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <img id="image" src="" alt="Imagem para ajuste">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                <button type="button" class="btn btn-primary" onclick="salvarAjustes()">Salvar Ajustes</button>
            </div>
        </div>
    </div>
</div>

            <!-- Exibir os dados atuais do usuário -->
            <p><strong>Nome:</strong> <?php echo $nome; ?></p>
            <p><strong>E-mail:</strong> <?php echo $email; ?></p>
            <p><strong>CEP:</strong> <?php echo $cep; ?></p>
            <p><strong>Rua:</strong> <?php echo $rua; ?></p>
            <p><strong>Município:</strong> <?php echo $municipio; ?></p>
            <p><strong>Estado:</strong> <?php echo $estado; ?></p>
            <p><strong>Telefone:</strong> <?php echo $telefone; ?></p>
            <!-- Adicione mais campos conforme necessário -->
        </div>
        </div>
        <div class="col-md-6">
    <h2>Atualizar Dados</h2>
    <!-- Formulário para atualização de dados -->
    <form action="atualiza_dados.php" method="post">
        <div class="form-group">
            <label for="nome">Novo Nome:</label>
            <input type="text" class="form-control" id="nome" name="nome">
        </div>
        <div class="form-group">
            <label for="novaSenha">Nova Senha:</label>
            <input type="password" class="form-control" id="novaSenha" name="novaSenha">
        </div>
        <div class="form-group">
            <label for="novoEmail">Novo E-mail:</label>
            <input type="email" class="form-control" id="novoEmail" name="novoEmail">
        </div>
        <div class="form-group">
            <label for="novoCEP">Novo CEP:</label>
            <input type="text" class="form-control" id="novoCEP" name="novoCEP">
        </div>
        <div class="form-group">
            <label for="novaRua">Nova Rua:</label>
            <input type="text" class="form-control" id="novaRua" name="novaRua">
        </div>
        <div class="form-group">
            <label for="novoMunicipio">Novo Município:</label>
            <input type="text" class="form-control" id="novoMunicipio" name="novoMunicipio">
        </div>
        <div class="form-group">
            <label for="novoEstado">Novo Estado:</label>
            <input type="text" class="form-control" id="novoEstado" name="novoEstado">
        </div>
        <div class="form-group">
            <label for="novoTelefone">Novo Telefone:</label>
            <input type="text" class="form-control" id="novoTelefone" name="novoTelefone">
        </div>
        <div class="form-group">
    <label for="senhaAntiga">Senha Antiga:</label>
    <input type="password" class="form-control" id="senhaAntiga" name="senhaAntiga" required>
</div>

        <button type="submit" class="btn btn-primary" name="atualizarDados">Atualizar Dados</button>
    </form>
</div>

    </div>
</div>
<script>
    // Adiciona o script para exibir os dados quando o usuário clicar na engrenagem
    document.addEventListener('DOMContentLoaded', function() {
        const btnEngrenagem = document.querySelector('.btn-engrenagem');
        const dadosUsuario = document.querySelector('.dados-usuario');

        btnEngrenagem.addEventListener('click', function() {
            dadosUsuario.style.display = (dadosUsuario.style.display === 'block') ? 'none' : 'block';
        });
    });
</script>
    <div class="row alinhar">
        <div class="card-home center-content">
            <div class="card">
                <div class="card-header">
                    Menu
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-6 d-flex justify-content-center opcao">
                            <a href="abrir_chamado.php" class="menu-link">
                                Abrir Chamado
                            </a>
                        </div>
                        <div class="col-6 d-flex justify-content-center opcao">
                            <a href='consultar_chamado.php' class="menu-link">
                                <span>  Consultar Chamado</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>